initial plugin idea implementation to insert a license/copyright based 
on some user specified string
